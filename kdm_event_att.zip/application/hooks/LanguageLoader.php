<?php
class LanguageLoader {
  function initialize() {
    $ci =& get_instance();
    $ci->load->helper('language');
    /* determine with file (name must same) */
    $siteLang = $ci->session->userdata('language');
    if ($siteLang) {
      $ci->lang->load('dictionary', $siteLang);
    } else {
			$ci->lang->load('dictionary', 'indonesia');
    }
  }
}