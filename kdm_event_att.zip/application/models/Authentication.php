<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Authentication extends CI_Model {

	public function encrypt($string) {
		$secret_key = 'indahjaya';
		$secret_iv = 'ij_pandora';

		$output = false;
		$encrypt_method = "AES-256-CBC";
		$key = hash('sha256', $secret_key);
		$iv = substr(hash('sha256', $secret_iv), 0, 16);
		$output = base64_encode(openssl_encrypt($string, $encrypt_method, $key, 0, $iv));
		return $output;
	}

	public function decrypt($string) {
		$secret_key = 'indahjaya';
		$secret_iv = 'ij_pandora';

		$output = false;
		$encrypt_method = "AES-256-CBC";
		$key = hash('sha256', $secret_key);
		$iv = substr(hash('sha256', $secret_iv), 0, 16);
		$output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
		return $output;
	}
}
?>