<?php
class kdm_att extends CI_Model{

  public function register_user($userdata){
    // echo "<pre>"; var_dump($userdata);echo "</pre>";exit;

    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://ejsoft.my.id/api/users',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_HTTPHEADER => array('Content-Type: application/json'),
        CURLOPT_POSTFIELDS =>'{
            "name": "'.$userdata['name'].'",
            "birth_date": "'.$userdata['birth_date'].'",
            "phone_number": "'.$userdata['phone_number'].'",
            "email_address": "'.$userdata['email_address'].'",
            "instagram_account": "'.$userdata['instagram_account'].'"
        }'
    ));

    $result = curl_exec($curl);
    $result = json_decode($result);
    curl_close($curl);
    
    if(!isset($result->message)){
        return true;
    }else{
        return false;
    }
  }
}
?>