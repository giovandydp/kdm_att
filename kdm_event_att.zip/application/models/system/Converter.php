<?php
class converter extends CI_Model{
	public function arrobj_to_arrass($arrobj,$index_attr){
		$ass_arrobj=[];
		for($i=0;$i<count($arrobj);$i++){
			$si=$arrobj[$i];
			$ass_arrobj[$si->{$index_attr}]=$si;
		}
		return $ass_arrobj;
	}
	public function switch_arr_dim($arr){
		$ret_arr=[];
		
		if(count($arr)>0){
			foreach($arr as $key=>$subarr){
				if(count($subarr)>0){
					foreach($subarr as $subkey=>$value){
						$ret_arr[$subkey][$key]=$value;
					}
				}
			}
		}
		return $ret_arr;
	}
	public function arrobj_to_arrarr($arrobj){
		$arrarr=[];
		foreach($arrobj as $obj){
			$arrobj_sub_1=get_object_vars($obj);
			$arr=[];
			foreach($arrobj_sub_1 as $attr=>$val){
				$arr[]=$val;
			}
			$arrarr[]=$arr;
		}
		return $arrarr;
	}
	public function dt_diff($dt_str_a,$dt_str_b){
		$dt_a=date_create($dt_str_a);
		$dt_b=date_create($dt_str_b);
		return date_diff($dt_a,$dt_b,true);
	}
	public function to_map($source_type,$source_data,$map_search_index_list,$map_value_index_list){
		$map=[];
		switch($source_type){
			case 'arrobj':
				$eval_str='$map';
				foreach($map_search_index_list as $map_search_index){
					$eval_str.='[$data->'.$map_search_index.']';
				}
				if(is_array($map_value_index_list)){
					$eval_str.='=[';
					$eval_value_arr=[];
					foreach($map_value_index_list as $map_value_index){
						$eval_value_arr[]='"'.$map_value_index.'"=>$data->'.$map_value_index;
					}
					$eval_str.=implode(",", $eval_value_arr).'];';
				}
				else{
					$eval_str.='=$data->'.$map_value_index_list.';';
				}

				//echo $eval_str."<br/>";
				//echo "<pre>";var_dump($source_data);echo"</pre>";
				foreach($source_data as $data){
					eval($eval_str);
				}
				break;
		}
		return $map;
	}

	public function number_to_month($number){
		switch($number){
			case 1 : return "Januari";break;
			case 2 : return "Februari";break;
			case 3 : return "Maret";break;
			case 4 : return "April";break;
			case 5 : return "Mei";break;
			case 6 : return "Juni";break;
			case 7 : return "Juli";break;
			case 8 : return "Agustus";break;
			case 9 : return "September";break;
			case 10 : return "Oktober";break;
			case 11 : return "November";break;
			case 12 : return "Desember";break;
			default: return "Undefined";break;
		}
	}

	public function number_to_wlocation($number){
		switch($number){
			case 0 : return "A";break;
			case 1 : return "B";break;
			case 2 : return "C";break;
			case 3 : return "D";break;
			case 4 : return "E";break;
			default: return "Undefined";break;
		}
	}
}

?>