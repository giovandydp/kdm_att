<?php
class builder extends CI_Model{
	public function json_response($code,$result=null,$ext1=null,$ext2=null){
		$json_response=new stdCLass;
		$json_response->code=$code;
		$json_response->result=$result;
		$json_response->ext1=$ext1;
		$json_response->ext2=$ext2;
		return json_encode($json_response);
	}	
	public function json_jquery_validation_response($code,$message=null,$ext=null){
		$json_response=new stdCLass;
		$json_response->code=$code;
		$json_response->message=$message;
		$json_response->ext=$ext;
		return json_encode($json_response);
	}	
}

?>