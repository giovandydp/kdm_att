<?php
class keygen extends CI_Model{

    public function generate_event_uid($event_type, $current_dt, $serial_length=6){
        switch ($event_type) {
            case 'onsite': $ecode = "ONS";break;
            case 'onsite': $ecode = "ONL";break;
            
            default: $ecode = "E";break;
        }
        $code=$ecode."-".date("Ymd", strtotime($current_dt))."-";
        
        $serial = date("His", strtotime($current_dt));
        $serial[0]=($serial[0]+1)%10;
        $serial[1]=($serial[1]+2)%10;
        $serial[2]=($serial[2]+3)%10;
        $serial[3]=($serial[3]+4)%10;
        $serial[4]=($serial[4]+5)%10;
        $serial[5]=($serial[5]+6)%10;
        
        return $code.$serial;
    }

    public function generate_member_uid($commission_category_uid, $current_dt, $serial_length=6){
        $code=$commission_category_uid."-".date("Ymd", strtotime($current_dt))."-";
        
        $serial = date("His", strtotime($current_dt));
        $serial[0]=($serial[0]+1)%10;
        $serial[1]=($serial[1]+2)%10;
        $serial[2]=($serial[2]+3)%10;
        $serial[3]=($serial[3]+4)%10;
        $serial[4]=($serial[4]+5)%10;
        $serial[5]=($serial[5]+6)%10;
        
        return $code.$serial;
    }

}

?>