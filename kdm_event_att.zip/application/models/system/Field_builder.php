<?php
class field_builder extends CI_Model{
    private $_type;
    private $_name;
    private $_id;
    private $_custom_class;
    private $_data_source;
    private $_custom_attr;
    private $_default_value;
    public function __construct(){
        parent::__construct();
        $this->reset();
    }
    public function reset(){
        $this->_type=null;
        $this->_name=null;
        $this->_id=null;
         $this->_custom_class=[
            "form-control",
            "input-sm"
        ];
        $this->_data_source=null;
        $this->_custom_attr=[];
        $this->_default_value=null;
    }
    public function type($type){
        $this->_type=$type;
        return $this;
    }
    public function custom_class($custom_class){
        foreach($custom_class as $custom){
            $this->_custom_class[]=$custom;
        }
        return $this;
    }
    public function name($name){
        $this->_name=$name;
        return $this;
    }
    public function id($id){
        $this->_id=$id;
        return $this;
    }
    public function data($data_source,$convert_from_dg=false,$id_col=null,$val_col=null,$have_empty_value=false){
        $converted_data_source=[];
        if($have_empty_value){
            if($have_empty_value===true){
                $converted_data_source['0']='-- Please Select --';
            }
            else{
                // $converted_data_source['']=$have_empty_value;
            }
        }
        if($convert_from_dg){
            if($have_empty_value===true){
                $converted_data_source['0']='-- Please Select --';
            }
            else{
                // $converted_data_source['']=$have_empty_value;
            }
            
            foreach($data_source as $data){
                $converted_data_source[$data->{$id_col}]=$data->{$val_col};
            }
        }
        else{
            $converted_data_source=$data_source;
        }
        
        $this->_data_source=$converted_data_source;
        return $this;
    }
    public function attr($custom_attr){
        $this->_custom_attr=$custom_attr;
        return $this;
    }
    public function default_value($default_value){
        $this->_default_value=$default_value;
        return $this;
    }
    public function fb_form_hidden($attr,$value){
        return "<input type='hidden' name='".$attr['name']."' id='".$attr['id']."' value='".$value."'/>";
    }
    public function build(){
        $build_result;
        $custom_class=implode(" ",$this->_custom_class);
        if($this->_id===null){
            $this->_id='fb-'.$this->_name;
        }

        switch($this->_type){
            case "hidden":
                $field_attr=[
                    'type'=>$this->_type,
                    'name'=>$this->_name,
                    'id'=>$this->_id
                ];
                $field_attr=array_merge($field_attr,$this->_custom_attr);
                $build_result=$this->fb_form_hidden($field_attr,$this->_default_value);
                break;
            case "text":
                $field_attr=[
                    'type'=>$this->_type,
                    'name'=>$this->_name,
                    'id'=>$this->_id,
                    'class'=>$custom_class
                ];
                $field_attr=array_merge($field_attr,$this->_custom_attr);
                $build_result=form_input($field_attr,$this->_default_value,$this->_custom_attr);
                break;
            case "password":
                $field_attr=[
                    'type'=>$this->_type,
                    'name'=>$this->_name,
                    'id'=>$this->_id,
                    'class'=>$custom_class
                ];
                $field_attr=array_merge($field_attr,$this->_custom_attr);
                $build_result=form_password($field_attr,$this->_default_value,$this->_custom_attr);
                break;
            case "number":
                $field_attr=[
                    'type'=>$this->_type,
                    'name'=>$this->_name,
                    'id'=>$this->_id,
                    'class'=>$custom_class
                ];
                $field_attr=array_merge($field_attr,$this->_custom_attr);
                $build_result=form_input($field_attr,$this->_default_value,$this->_custom_attr);
                break;
            case "select":
                $field_attr=$this->_custom_attr;
                $field_attr['class']=$custom_class;
                $field_attr['id']=$this->_id;
                $build_result=form_dropdown($this->_name,$this->_data_source,$this->_default_value,$field_attr);
                break;
            case "enum":
                $field_attr=$this->_custom_attr;
                $field_attr['class']=$custom_class;
                $field_attr['id']=$this->_id;
                $build_result=form_dropdown($this->_name,$this->_data_source,$this->_default_value,$field_attr);
                break;
            case "textarea":
                $field_attr=[
                    'type'=>$this->_type,
                    'name'=>$this->_name,
                    'id'=>$this->_id,
                    'class'=>$custom_class
                ];
                $field_attr=array_merge($field_attr,$this->_custom_attr);
                $build_result=form_textarea($field_attr,$this->_default_value,$this->_custom_attr);
                break;
            case "richtext":
                $field_attr=[
                    'type'=>$this->_type,
                    'name'=>$this->_name,
                    'id'=>$this->_id,
                    'class'=>$custom_class
                ];
                $field_attr=array_merge($field_attr,$this->_custom_attr);
                $build_result=form_textarea($field_attr,$this->_default_value,$this->_custom_attr);
                attach_script($build_result,"
                    $(document).ready(function(){
                        CKEDITOR.replace('".$this->_name."');
                    });
                ");
                break;
            case "upload":
                $field_attr=[
                    'type'=>$this->_type,
                    'name'=>$this->_name,
                    'id'=>$this->_id,
                    'class'=>$custom_class
                ];
                $field_attr=array_merge($field_attr,$this->_custom_attr);
                $build_result=form_upload($field_attr,$this->_default_value,$this->_custom_attr);
                break;
        }
        
        $this->reset();
        return $this->formater->remove_endline($build_result);
    }

}
?>