<?php
class exporter extends CI_Model{
	public function to_excel($s_name,$h,$d,$filename){
		$s_size=count($s_name);
        $this->load->library("xlsxwriter");
        $report_name=$filename.".xlsx";
        header('Content-disposition: attachment; filename="'.XLSXWriter::sanitize_filename($report_name).'"');
        header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        header('Content-Transfer-Encoding: binary');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        $writer = new XLSXWriter();
        $writer->setAuthor('Indah Jaya - Production');
        for($i=0;$i<$s_size;$i++){
            $writer->writeSheet($d[$i],$s_name[$i],$h[$i]);
        }
        $writer->writeToStdOut();
    }
}

?>