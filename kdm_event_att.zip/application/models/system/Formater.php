<?php
class formater extends CI_Model{
	public function table_th($val){
		return ucwords(preg_replace('/_+/', ' ', $val));
	}	
	public function general($val,$type,$row=null,$ext=[]){
		$ret_val;
		if(isset($ext['data'])){
			foreach($ext['data'] as $key_name=>$key_value){
				$key_value_arr=explode("::", $key_value);
				$translated_key_valuer_arr=[];
				foreach($key_value_arr as $idx=>$value){
					$translated_value=$value;
					if(isset($row->{$value})){
						$translated_value=$row->{$value};
					}
					$translated_key_valuer_arr[]=$translated_value;
				}
				$translated_key_value=implode("", $translated_key_valuer_arr);
				$ext['data'][$key_name]=$translated_key_value;
			}
		}
		switch($type){
			case "numeric":
				$ret_val=number_format($val,2);
				break;
			case "date":
				$ret_val=date("d M Y",strtotime($val));
				break;
			case "boolean":
				if($val){
					$ret_val="Yes";
				}
				else
					$ret_val="No";
				break;
			case "url":
				$ret_val=anchor($val,"Link",array("target"=>"_blank"));
				break;
			case "url_appended":
				$ret_val=anchor($ext['url'].'/'.$val,$val,array("target"=>"_blank"));
				break;
			case "image":
				$ret_val="<img src='".$val."' ";
				if(isset($ext['width'])){
					$ret_val.=" width='".$ext['width']."'";
				}
				if(isset($ext['height'])){
					$ret_val.=" height='".$ext['height']."'";
				}
				$ret_val.=" />";
				break;
			case "dropdown":
				
				$data_list_h=$this->html->generate_dropdown($ext['data']['dropdown_name'],$ext['dataset'],$ext['table_column_id'],$ext['table_column_display'],$ext['data']['dropdown_selected_value']);
				$ret_val=$data_list_h;
				break;
			case "input-numeric":
				$ret_val=form_input($ext['data']['input_name'],$ext['data']['input_value'],['type'=>'number','min'=>'0','class'=>'form-control']);
				break;
			case "enum-string":
				$ret_val=ucwords(preg_replace('/_+/', ' ', $val));
				break;
			case "string":
			default:
				$ret_val=$val;
				break;
		}
		return $ret_val;
	}
	public function remove_endline($str){
		return preg_replace("/[\n\r]/","",$str);
	}
	public function dump($var){
		
		//echo "<pre>";
		//var_dump($var);
		//echo "</pre><br/>";
		
	}
}

?>