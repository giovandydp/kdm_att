<?php
class dbconnector extends CI_Model{
	private $trx_started=false;
	function InsertData($tableName,$data){
		$this->db->insert($tableName,$data);
        if($this->db->affected_rows()>0) 
			return $this->db->insert_id();
		else return false;
		
	}
	function insertignore($tableName,$data){
		$insert_query = $this->db->insert_string($tableName, $data);
		$insert_query = str_replace('INSERT INTO','INSERT IGNORE INTO',$insert_query);
		$this->db->query($insert_query);
        if($this->db->affected_rows()>0) 
			return $this->db->insert_id();
		else return false;
		
	}
	function UpdateData($tableName,$newData,$whereCondition){
		$this->db->where($whereCondition);
		$this->db->update($tableName,$newData);
        if($this->db->affected_rows()>0) 
			return true;
		else return false;
		//echo "DATA UPDATED";
	}
	function UpdateDataUnprotected($tableName,$newData,$whereCondition){
		foreach($newData as $key=>$value){
			$this->db->set($key,$value,false);
		}
		$this->db->where($whereCondition);
		$this->db->update($tableName);
        if($this->db->affected_rows()>0) 
			return true;
		else return false;
		//echo "DATA UPDATED";	
	}
	
	function RunQuery($query,$mode="object"){
		//var_dump($query);
		
		$result=$this->db->query($query);
		if(@$result->result_id->num_rows==0)
			return null;
		else {
			if($mode==="object"){
				return $result->result_object();
			}
			else if($mode==="array"){
				return $result->result_array();
			}
			else return $result->result_object();
		}
	}
	function RunSingleRowQuery($query,$mode="object"){
		$result=$this->RunQuery($query);
		if($result!==null){
			$result=$result[0];
			return $result;
		}
		else return null;
	}
	function RunSingleCellQuery($query,$colName,$defaultVal=null){
		$result=$this->RunSingleRowQuery($query);
		if($result!==null){
			$result=$result->$colName;
		}
		else{
			$result=$defaultVal;
		}
		return $result;
	}
	function RunUpdateQuery($query){
		$result=$this->db->query($query);
		return $result;//false or true
	}
	function InsertBatch($table_name,$data){
		$this->db->insert_batch($table_name,$data);
	}
	function ReplaceBatch($table_name,$data){
		for($i=0;$i<count($data);$i++){
			$insert_query = $this->db->insert_string($table_name, $data[$i]);
			$insert_query = str_replace('INSERT INTO','REPLACE INTO',$insert_query);
			$this->db->query($insert_query);
		}
	}
	function Start_Transaction(){
		$this->db->trans_begin();
	}
	function End_Transaction(){
		if ($this->db->trans_status() === FALSE)
		{
		    $this->db->trans_rollback();
		}
		else
		{
		    $this->db->trans_commit();
		}
	}
	function rollback_transaction(){
		$this->db->trans_rollback();
	}
	function DeleteData($tableName,$whereCondition){
		$this->db->where($whereCondition);
		$this->db->delete($tableName);
        if($this->db->affected_rows()>0) 
			return true;
		else return false;
		//echo "DATA UPDATED";
	}
}
?>