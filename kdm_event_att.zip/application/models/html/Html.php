<?php
class html extends CI_Model{
	private $default_dropdown_js='class="form-control"';

	public function form_input_group($form_input,$icon,$icon_dir="right"){
		$input_group="<div class='input-group'>";
		$icon="<span class='input-group-addon'><i class='".$icon."'></i></span>";
		if($icon_dir==="left"){
			$input_group.=$icon;
		}
		$input_group.=$form_input;
		if($icon_dir==="right"){
			$input_group.=$icon;
		}
		$input_group.="</div>";
		return $input_group;
	}
	public function generate_selection($name,$id_html,$target_url,$default_val='',$default_val_h=''){
		$id_hidden=$id_html.'-hidden';

		$html="";

		$html=$this->form_input_group(form_input(null,$default_val,['readonly'=>true,'id'=>$id_html,'class'=>'form-control','style'=>'cursor:pointer;']),"fa fa-search","right");
		$html.=form_hidden($name,$default_val_h,['id'=>$id_hidden]);
		
		return ['html'=>$html,'url'=>$target_url,'id'=>$id_html,'id_hidden'=>$id_hidden];
	}
	public function generate_dropdown($name,$options,$key="",$value="",$selected_val="",$js='class="form-control"',$extra_param_flag=true,$pure_arr=false){
		if($js===null){
			$js=$this->default_dropdown_js;
		}
		if($options===null){
			$options=[];
		}
		$options_arr=array();
		
		if($extra_param_flag){
			$options_arr["-1"]="-- Please Select --";
		}
		if(!$pure_arr){
			
			for($i=0;$i<count($options);$i++){
				$si=$options[$i];
				$options_arr[$si[$key]]=$si[$value];
			}
		}
		else{
			$options_arr=array_merge($options_arr,$options);
		}
		
		return form_dropdown($name,$options_arr,$selected_val,$js);
	}
	public function generate_dropdown_extra($name,$options,$key="",$value="",$extra="",$selected_val="",$js='class="form-control"',$extra_param_flag=true,$pure_arr=false){
		if($js===null){
			$js=$this->default_dropdown_js;
		}
		$options_arr=array();
		
		if($extra_param_flag){
			$options_arr["-1"]=new stdClass;
			$options_arr["-1"]->value="-- Please Select --";
			$options_arr["-1"]->extra="0";
		}
		for($i=0;$i<count($options);$i++){
			$si=$options[$i];
			$options_arr[$si[$key]]=new stdClass;
			$options_arr[$si[$key]]->value=$si[$value];
			$options_arr[$si[$key]]->extra=$si[$extra];
		}
		$ret_html= '<select $js name="'.$name.'">';
		foreach($options_arr as $key_name=>$obj){
			$ret_html.= '<option value="'.$key_name.'" title="'.$obj->extra.'">'.$obj->value.'</option>';
		}
		$ret_html.= "</select>";
		return $ret_html;
	}
	public function generate_multiselect($name,$options,$key="",$value="",$selected_val="",$js='class="form-control"',$pure_arr=false){
		if($js===null){
			$js=$this->default_dropdown_js;
		}
		$options_arr=array();
		
		if(!$pure_arr){
			
			for($i=0;$i<count($options);$i++){
				$si=$options[$i];
				$options_arr[$si[$key]]=$si[$value];
			}
		}
		else{
			$options_arr=$options;
		}
		return form_multiselect($name,$options_arr,$selected_val,$js);
	}
	public function generate_checkbox_list($array_name,$options,$key,$value,$selected_val=array(),$js='class="form-control"'){
		$checkbox_list="";
		$checkbox_arr=array();
		//if(count($selected_val)!==0)echo"SEL : ";var_dump($selected_val);

		for($i=0;$i<count($options);$i++){
			$si=$options[$i];
			$is_checked=false;
			//echo " ".$si[$key]." ";
			if(in_array($si[$key], $selected_val)){
				$is_checked=true;
			}
			$checkbox_list.=form_checkbox(array(
				"name"=>"$array_name"."[".$si[$key]."]",
				"value"=>$si[$key],
				"checked"=>$is_checked,
				"style"=>"margin:10px"
			)).$si[$value];
		}
		return $checkbox_list;
	}
	public function generate_radio_list($name,$options,$key="",$value="",$selected_val=array(),$js='class="form-control"',$pure_arr=false){
		$radio_list="";
		$radio_arr=array();
		//if(count($selected_val)!==0)echo"SEL : ";var_dump($selected_val);
		if($pure_arr){
			foreach($options as $v_key=>$v_value){
				$is_checked=false;
				if(in_array($v_key, $selected_val)){
					$is_checked=true;
				}
				$radio_list.=form_radio(array(
					"name"=>$name,
					"value"=>$v_key,
					"checked"=>$is_checked,
					"style"=>"margin:0px"
				)).$v_value;
			}
		}
		else{
			for($i=0;$i<count($options);$i++){
				$si=$options[$i];
				$is_checked=false;
				//echo " ".$si[$key]." ";
				if(in_array($si[$key], $selected_val)){
					$is_checked=true;
				}
				$radio_list.=form_radio(array(
					"name"=>$name,
					"value"=>$si[$key],
					"checked"=>$is_checked,
					"style"=>"margin:0px"
				)).$si[$value];
			}
		}
		return $radio_list;
	}
	
}
?>