<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Query extends CI_Model {

	public function select($statement) {
		$this->db->select($statement);
		return $this;
	}

	public function from($table_name) {
		$this->db->from($table_name);
		return $this;
	}

	// you can set join table with direction functionality such as left or right
	public function join($table_name, $statement, $direction = 'left') {
		$this->db->join($table_name, $statement, $direction);
		return $this;
	}

	public function where($statement, $limit = null, $offset = null) {
		$this->db->where($statement, $limit, $offset);
		return $this;
	}

	public function orWhere($statement, $limit = null, $offset = null) {
		$this->db->or_where($statement, $limit, $offset);
		return $this;
	}

	public function whereIn($statement, $limit = null, $offset = null) {
		$this->db->where_in($statement, $limit, $offset);
		return $this;
	}

	public function orWhereIn($statement, $limit = null, $offset = null) {
		$this->db->or_where_in($statement, $limit, $offset);
		return $this;
	}

	public function whereNotIn($statement, $limit = null, $offset = null) {
		$this->db->where_not_in($statement, $limit, $offset);
		return $this;
	}

	public function orWhereNotIn($statement, $limit = null, $offset = null) {
		$this->db->or_where_not_in($statement, $limit, $offset);
		return $this;
	}

	public function limit($limit, $offset = null) {
		$this->db->limit($limit, $offset);
		return $this;
	}

	// side = 'both', 'before', 'after'
	// can be used with associative array method
	public function like($statement, $search = '', $side = 'both') {
		$this->db->like($statement, $search, $side);
		return $this;
	}

	public function orLike($statement, $search = '', $side = 'both') {
		$this->db->or_like($statement, $search, $side);
		return $this;
	}

	public function notLike($statement, $search = '', $side = 'both') {
		$this->db->not_like($statement, $search, $side);
		return $this;
	}

	public function orNotLike($statement, $search = '', $side = 'both') {
		$this->db->or_not_like($statement, $search, $side);
		return $this;
	}

	// ex. ->groupBy("title");
	// ex. ->groupBy(array("title", "date"))
	public function groupBy($statement) {
		$this->db->group_by($statement);
		return $this;
	}

	// ex. ->orderBy("title asc", "name desc");
	public function orderBy($statement) {
		$this->db->order_by($statement);
		return $this;
	}

	public function update($table, $set, $where) {
		$this->db->trans_begin();

		$this->db->update($table, $set, $where);

		if ($this->db->trans_status() !== false) {
			$this->db->trans_commit();
			return true;
		} else {
			$this->db->trans_rollback();
			return false;
		}
	}

	public function insert($table, $data) {
		$this->db->trans_begin();

		$this->db->insert($table, $data);

		if ($this->db->trans_status() !== false) {
			$this->db->trans_commit();
			return true;
		} else {
			$this->db->trans_rollback();
			return false;
		}
	}

	public function delete($table, $where) {
		$this->db->trans_begin();

		$this->db->delete($table, $where);

		if ($this->db->trans_status() !== false) {
			$this->db->trans_commit();
			return true;
		} else {
			$this->db->trans_rollback();
			return false;
		}
	}

	public function truncate($table) {
		$this->db->trans_begin();

		$this->db->truncate($table);

		if ($this->db->trans_status() !== false) {
			$this->db->trans_commit();
			return true;
		} else {
			$this->db->trans_rollback();
			return false;
		}
	}

	// get all result from select *
	public function allResult() {
		$getDB = $this->db->get();
		$result = $getDB->result_object();
		return $result;
	}

	// get single result from select where
	public function singleResult() {
		$getDB = $this->db->get();
		$result = $getDB->row_object();
		return $result;
	}

	// get only value result froms select
	public function valueResult($value) {
		$getDB = $this->db->get();
		$result = $getDB->row($value);
		return $result;
	}

	public function reset() {
		$this->db->reset_query();
		return $this;
	}
}