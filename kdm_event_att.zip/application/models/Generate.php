<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Generate extends CI_Model {

	public function randomString($length) {
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%&*';
		$cLength = strlen($characters);
		$random = '';

		for ($i=0; $i<$length; $i++) {
			$random .= $characters[rand(0, $cLength - 1)];
		}
		return $random;
	}

	public function doc_code($prefix,$type,$serial_length=6,$option=[]){
        // $this->load->model("dbconnector");
        $rand_str=$this->random_str($serial_length);
        $delimiter="-";
        if(isset($option['delimiter'])){
            $delimiter=$option['delimiter'];
        }
        $code=$prefix.$delimiter.date("Ymd").$delimiter;
        if(isset($option['no_date'])){
            $code=$prefix.$delimiter;
        }
        if(isset($option['mask'])){
            return $prefix."-xxxxxx";
        }

        $serial=date("His");
        $serial[0]=($serial[0]+1)%10;
        $serial[1]=($serial[1]+2)%10;
        $serial[2]=($serial[2]+3)%10;
        $serial[3]=($serial[3]+4)%10;
        $serial[4]=($serial[4]+5)%10;
        $serial[5]=($serial[5]+6)%10;
        
        return $code.$serial;

        // switch($type){
        //     case "ftp_cash_redeem":
        //         $query="SELECT max(ftp_cash_redeem_code) 'max_code' from ftp_cash_redeem where ftp_cash_redeem_code like '$code%'";
        //         break;
        //     case "longrich_cash_topup":
        //         $query="SELECT max(longrich_cash_topup_code) 'max_code' from longrich_cash_topup where longrich_cash_topup_code like '$code%'";
        //         break;
        //     case "longrich_cash_token":
        //         $query="SELECT max(longrich_cash_token_code) 'max_code' from longrich_cash_token where longrich_cash_token_code like '$code%'";
        //         break;
        //     case "longrich_cash_redeem":
        //         $query="SELECT max(longrich_cash_redeem_code) 'max_code' from longrich_cash_redeem where longrich_cash_redeem_code like '$code%'";
        //         break;
        //     case "longrich_cash_redeem_setting":
        //         $query="SELECT max(longrich_cash_redeem_setting_code) 'max_code' from longrich_cash_redeem_setting where longrich_cash_redeem_setting_code like '$code%'";
        //         break;
        //     case "longrich_cash_transfer":
        //         $query="SELECT max(longrich_cash_transfer_code) 'max_code' from longrich_cash_transfer where longrich_cash_transfer_code like '$code%'";
        //         break;
        //     case "longrich_cash_addition":
        //         $query="SELECT max(longrich_cash_addition_code) 'max_code' from longrich_cash_addition where longrich_cash_addition_code like '$code%'";
        //         break;
        //     case "longrich_cash_deduction":
        //         $query="SELECT max(longrich_cash_deduction_code) 'max_code' from longrich_cash_deduction where longrich_cash_deduction_code like '$code%'";
        //         break;
        //     case "stockist_cash_topup":
        //         $query="SELECT max(stockist_cash_topup_code) 'max_code' from stockist_cash_topup where stockist_cash_topup_code like '$code%'";
        //         break;
        //     case "stockist_cash_addition":
        //         $query="SELECT max(stockist_cash_addition_code) 'max_code' from stockist_cash_addition where stockist_cash_addition_code like '$code%'";
        //         break;
        //     case "stockist_cash_deduction":
        //         $query="SELECT max(stockist_cash_deduction_code) 'max_code' from stockist_cash_deduction where stockist_cash_deduction_code like '$code%'";
        //         break;
        //     case "inventory_in":
        //         $query="SELECT max(inventory_in_code) 'max_code' from inventory_in where inventory_in_code like '$code%'";
        //         break;
        //     case "inventory_adjustment":
        //         $query="SELECT max(inventory_adjustment_code) 'max_code' from inventory_adjustment where inventory_adjustment_code like '$code%'";
        //         break;
        //     case "inventory_out":
        //         $query="SELECT max(inventory_out_code) 'max_code' from inventory_out where inventory_out_code like '$code%'";
        //         break;
        //     case "faulty_product":
        //         $query="SELECT max(faulty_product_code) 'max_code' from faulty_product where faulty_product_code like '$code%'";
        //         break;
        //     case "product_loan":
        //         $query="SELECT max(product_loan_code) 'max_code' from product_loan where product_loan_code like '$code%'";
        //         break;
        //     case "product_loan_return":
        //         $query="SELECT max(product_loan_return_code) 'max_code' from product_loan_return where product_loan_return_code like '$code%'";
        //         break;
        //     case "sales_order":
        //         $serial=date("His");
        //         $serial[0]=($serial[0]+1)%10;
        //         $serial[1]=($serial[1]+2)%10;
        //         $serial[2]=($serial[2]+3)%10;
        //         $serial[3]=($serial[3]+4)%10;
        //         $serial[4]=($serial[4]+5)%10;
        //         $serial[5]=($serial[5]+6)%10;
        //         return $code.$serial;
        //         // $query="SELECT max(sales_order_code) 'max_code' from sales_order where sales_order_code like '$code%'";
        //         break;
        //     case "stockist_replenishment":
        //         $query="SELECT max(stockist_replenishment_code) 'max_code' from stockist_replenishment where stockist_replenishment_code like '$code%'";
        //         break;
        //     case "exchange":
        //         $query="SELECT max(exchange_code) 'max_code' from exchange where exchange_code like '$code%'";
        //         break;
        // }   
        // $max_code=$this->dbconnector->runsinglerowquery($query);
        // if($max_code===null){
        //     $max_code= 0;
        // }
        
        // $serial=substr($max_code->max_code,strlen($code))+1;

        // return $code.str_pad($serial,$serial_length,"0",STR_PAD_LEFT);
        
    }
}
?>