<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Template extends CI_Model {

	public function template_mainsys(&$view_data) {
		$view_data['global_js'] = $this->load->view('mainsys/template/script_link', NULL, true);
		$view_data['global_css'] = $this->load->view('mainsys/template/style_link', NULL, true);
		$view_data['navbar'] = $this->load->view('mainsys/template/navbar', NULL, true);
		$view_data['sidebar'] = $this->load->view('mainsys/template/sidebar', $view_data, true);
		$view_data['footer'] = $this->load->view('mainsys/template/footer', NULL, true);
	}
}