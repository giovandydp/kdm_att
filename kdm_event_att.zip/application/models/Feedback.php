<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Feedback extends CI_Model {

	public function alert($type, $message) {

		$alert_success = "
				<script>
					toastr.success('".$message."');
				</script>";

		$alert_warning = "
				<script>
					toastr.warning('".$message."');
				</script>";

		$alert_failed = "
				<script>
					toastr.error('".$message."');
				</script>";

		$alert_default = "
				<script>
					toastr.info('".$message."');
				</script>";

		switch($type) {
			case 'success': 
				$this->session->set_flashdata('feedback_msg', $alert_success);
				break;
			case 'warning': 
				$this->session->set_flashdata('feedback_msg', $alert_warning);
				break;
			case 'failed': 
				$this->session->set_flashdata('feedback_msg', $alert_failed);
				break;
			default: 
				$this->session->set_flashdata('feedback_msg', $alert_default);
				break;
		}
	}
}
?>