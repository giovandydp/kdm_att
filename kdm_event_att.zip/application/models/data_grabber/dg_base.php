<?php
class dg_base extends CI_Model {
	public $selected_table="";
	protected $join_table=[];
	protected $order_by="";
	protected $last_get;
	protected $function_list=[];
	protected $_active_db=null;

	public function __construct(){
		$this->_active_db=$this->db;
	}
	public function choose_db($db_name){
		$this->_active_db=$this->load->database($db_name,true);
	}
	public function append_join_table($join_table){
		// tambahin join
		for($i=0;$i<count($join_table);$i++){
			$has_join_previously=false;
			foreach($this->join_table as $joined_table){
				if($joined_table['join_with']===$join_table[$i]['join_with']){
					//skip joining same table
					$has_join_previously=true;
					break;
				}
			}
			if(!$has_join_previously)
				array_push($this->join_table, $join_table[$i]);
		}
		return $this;
	}
	public function remove_join_table($join_with){
		// echo "JOIN WITH : ";var_dump($join_with);echo " : ";
		for($j=0;$j<count($join_with);$j++){
			// echo " ; ".$j." ; ";
			for($i=0;$i<count($this->join_table);$i++){
				if($this->join_table[$i]['join_with']===$join_with[$j]){
					unset($this->join_table[$i]);
					$this->join_table=array_values($this->join_table);
				}
			}
		}
		$this->join_table=array_values($this->join_table);
	}
	public function enum_values($column_name){
		//enum values
		$this->build();
		$query="SHOW COLUMNS FROM ".$this->selected_table." WHERE Field = '".$column_name."'";
		$type = $this->_active_db->query($query)->row(0)->Type;
	    preg_match("/^enum\(\'(.*)\'\)$/", $type, $matches);
	    $enum = explode("','", $matches[1]);
	    $formed_enum=array();
	    for($i=0;$i<count($enum);$i++){
	    	$formed_enum[$enum[$i]]=$enum[$i];
	    }
	    $this->reset();
	    return $formed_enum;
	}
	
	public function build(){
		$this->_active_db->from($this->selected_table);
		for($i=0;$i<count($this->join_table);$i++){
			$this->_active_db->join($this->join_table[$i]['join_with'],$this->join_table[$i]['join_on'],$this->join_table[$i]['join_dir']);
		}
		return $this;
	}
	public function raw_query($query){
		$result=$this->_active_db->query($query);
		if(!is_bool($result)){
			$data_list=$result->result();
			foreach($this->function_list as $function){
				$function_name=$function['name'];
				$function_params=$function['params'];
				$data_list=$this->$function_name($data_list,$function_params);
			}
			$this->reset();
			return $data_list;
		}
	}
	public function _get($limit=NULL,$offset=NULL){
		$this->build();
		$result=$this->_active_db->get($limit,$offset);
		$this->last_get=$result;
		
		return $result;
	}
	public function last_get(){
		return $this->last_get;
	}
	public function glist($type="object"){
		$result=$this->_get();
		switch($type){
			case "object":
				$data_list=$result->result_object();
				break;
			case "array":
				$data_list=$result->result_array();
				break;
		}
		foreach($this->function_list as $function){
			$function_name=$function['name'];
			$function_params=$function['params'];
			$data_list=$this->$function_name($data_list,$function_params);
		}
		$this->reset();
		return $data_list;
	}
	public function single($type="object"){
		$result=$this->limit(1)->glist($type);
		if(count($result)===0){
			return null;
		}
		else return $result[0];
	}
	public function value($column){
		$result=$this->single("array");

		if($result===null){
			return null;
		}
		else{
			if(isset($result[$column])){
				return $result[$column];
			}
			else
				return null;
		}
	}
	public function column($column){//return pure arr
		$result=$this->glist("array");
		if($result===null){
			return null;
		}
		else{
			$data_column=[];
			foreach($result as $result_item){
				$data_column[]=$result_item[$column];
			}
			return $data_column;
		}
	}
	public function size(){
		$result=$this->glist();
		return count($result);
	}
	public function select($column){
		$this->_active_db->select($column);
		return $this;
	}
	public function select_h($header_arr){
		$column="";
		$header_size=count($header_arr);
		$header_count=0;
		foreach($header_arr as $column_alias=>$column_data){
			$column.=$column_data['column'];
			$column.=" as '".$column_alias."'";
			
			$header_count++;

			if($header_count<$header_size){
				$column.=",";
			}
		}

		$this->_active_db->select($column);
		return $this;
	}
	public function order_by($order_by){
		$this->_active_db->order_by($order_by);
		return $this;
	}
	public function where($key,$value=null,$escape=null){
		$this->_active_db->where($key,$value,$escape);
		return $this;
	}
	public function or_where($key,$value=null,$escape=null){
		$this->_active_db->or_where($key,$value,$escape);
		return $this;
	}
	public function where_in($key,$value=null,$escape=null){
		$this->_active_db->where_in($key,$value,$escape);
		return $this;
	}
	public function or_where_in($key,$value=null,$escape=null){
		$this->_active_db->or_where_in($key,$value,$escape);
		return $this;
	}
	public function where_not_in($key,$value=null,$escape=null){
		$this->_active_db->where_not_in($key,$value,$escape);
		return $this;
	}
	public function or_where_not_in($key,$value=null,$escape=null){
		$this->_active_db->or_where_not_in($key,$value,$escape);
		return $this;
	}
	public function like($field,$match='',$side='both',$escape=null){
		$this->_active_db->like($field,$match,$side,$escape);
		return $this;
	}
	public function or_like($field,$match='',$side='both',$escape=null){
		$this->_active_db->or_like($field,$match,$side,$escape);
		return $this;
	}
	public function not_like($field,$match='',$side='both',$escape=null){
		$this->_active_db->not_like($field,$match,$side,$escape);
		return $this;
	}
	public function or_not_like($field,$match='',$side='both',$escape=null){
		$this->_active_db->or_not_like($field,$match,$side,$escape);
		return $this;
	}
	public function group_by($by,$escape=null){
		$this->_active_db->group_by($by,$escape);
		return $this;
	}
	public function distinct($val=true){
		$this->_active_db->distinct($val);
		return $this;
	}
	public function having($key,$value=null,$escape=null){
		$this->_active_db->having($key,$value,$escape);
		return $this;
	}
	public function or_having($key,$value=null,$escape=null){
		$this->_active_db->or_having($key,$value,$escape);
		return $this;
	}
	public function limit($value,$offset=0){
		$this->_active_db->limit($value,$offset);
		return $this;
	}
	public function group_start($not='',$type='AND '){
		$this->_active_db->group_start($not,$type);
		return $this;
	}
	public function or_group_start(){
		$this->group_start('', 'OR ');
		return $this;
	}
	public function not_group_start(){
		$this->group_start('NOT ', 'AND ');
		return $this;
	}
	public function or_not_group_start(){
		$this->group_start('NOT ', 'OR ');
		return $this;
	}
	public function group_end(){
		$this->_active_db->group_end();
		return $this;
	}
	public function insert($set,$escape=null){
		$insert_result=$this->_active_db->insert($this->selected_table,$set,$escape);
		$this->reset();
		
		if($insert_result!==false){
			$insert_id = $this->_active_db->insert_id();
			if($insert_id==0){
				return true;
			}
			else{
				return $insert_id;
			}
		}
		else{
			if($this->_active_db->affected_rows()>0){
				return true;
			}
			else{
				return false;
			}
		}

	}
	public function insert_batch($set=NULL,$escape=NULL,$batch_size=100){
		$insert_batch_result=$this->_active_db->insert_batch($this->selected_table,$set,$escape,$batch_size);
		$this->reset();
		return $insert_batch_result;
	}
	public function replace($set){
		$replace_result=$this->_active_db->replace($this->selected_table,$set);
		$this->reset();
		return $replace_result;
	}
	public function update($set,$where=null,$limit=null){
		$update_result=$this->_active_db->update($this->selected_table,$set,$where,$limit);
		$this->reset();
		if($this->_active_db->affected_rows()>0){
			return true;
		}
		else {
			return $update_result;
		}
	}
	public function update_batch($set=NULL,$index=NULL,$batch_size=100){
		$update_batch_result=$this->_active_db->update_batch($this->selected_table,$set,$index,$batch_size);
		$this->reset();
		return $update_batch_result;
	}
	public function delete($where = '', $limit = NULL, $reset_data = TRUE){
		$delete_result=$this->_active_db->delete($this->selected_table,$where,$limit,$reset_data);
		$this->reset();
		return $delete_result;
	}
	public function empty_data(){
		$empty_result=$this->_active_db->empty_table($this->selected_table);
		$this->reset();
		return $empty_result;
	}
	public function truncate(){
		$truncate_result=$this->_active_db->truncate($this->selected_table);
		$this->reset();
		return $truncate_result;
	}
	public function reset(){
		$this->_active_db->reset_query();
		$this->function_list=[];	
	}
	public function get_compiled_select($reset=false){
		$this->build();
		return $this->_active_db->get_compiled_select($this->selected_table,$reset);
	}
	public function with($function,$function_params=null){
		if(is_array($function)){
			foreach($function as $f){
				$this->function_list[]=$f;
			}
		}
		else{
			$this->function_list[]=[
				'name'=>$function,
				'params'=>$function_params
			];
		}
		return $this;
	}
}
?>
