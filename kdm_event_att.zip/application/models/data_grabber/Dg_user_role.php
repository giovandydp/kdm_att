<?php
require_once("dg_base.php");
class dg_user_role extends dg_base {
	public function __construct(){
		parent::__construct();
		$this->selected_table="user_role";
	}
}
?>
