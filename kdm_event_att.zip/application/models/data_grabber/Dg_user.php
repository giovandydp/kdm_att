<?php
require_once("dg_base.php");
class dg_user extends dg_base {
	public function __construct(){
		parent::__construct();
		$this->selected_table="user";
		$this->append_join_table([
			[
				"join_with"	=> "user_role",
				"join_on"	=> "user.role_code=user_role.role_code",
				"join_dir"	=> "left"
			]
		]);
	}
}
?>
