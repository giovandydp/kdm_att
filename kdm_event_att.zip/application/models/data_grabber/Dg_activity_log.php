<?php
require_once("dg_base.php");
class dg_activity_log extends dg_base {
	public function __construct(){
		parent::__construct();
		$this->selected_table="activity_log";
		// $this->append_join_table([
		// 	[
		// 		"join_with"	=> "",
		// 		"join_on"	=> "",
		// 		"join_dir"	=> "left"
		// 	]
		// ]);
	}
	
}
?>
