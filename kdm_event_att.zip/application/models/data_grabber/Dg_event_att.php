<?php
require_once("dg_base.php");
class dg_event_att extends dg_base {
	public function __construct(){
		parent::__construct();
		$this->selected_table="event_att";
	}
}
?>
