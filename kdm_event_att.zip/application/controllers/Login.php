<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class login extends CI_Controller {
	protected $subject="Login";
	protected $main_controller="login";
	protected $view_data=[];

	public function __construct() {
		parent::__construct();
		$this->view_data['subject'] = $this->subject;
		$this->load->model('authentication');
		$this->load->model('data_grabber/dg_user');
		$this->view_data['main_controller']=$this->main_controller;
	}

	public function index() {
		$this->admin_login();
	}

	public function admin_login(){
		$this->template->template_mainsys($this->view_data);

		$this->view_data['content'] = $this->load->view("mainsys/content/login/login_form", $this->view_data, true);
		$this->load->view("mainsys/template/master_layout_login", $this->view_data);
	}

	public function do_login(){
		$data = $this->input->post('login');

		$username = strtolower($data['username']);
		$password = $this->authentication->encrypt(strtolower($data['password']));
		// echo "<pre>";var_dump($password);echo "</pre>";exit;
		$user_data = $this->dg_user->select("user.*,user_role.role_code,user_role.role_name")->group_start()->where("user.nik",$username)->or_where("user.user_name",$username)->group_end()->where("user.user_password",$password)->single();
		
		if (empty($user_data)) {
			$this->feedback->alert("failed", "Wrong Email/Username/Password");

			redirect('login');
		} else {
			if($user_data->user_status == "banned"){
				$this->feedback->alert("failed", "Your account has been banned, please contact us for more info.");
				redirect('login');
			}
			else if($user_data->user_status == "inactive" || $user_data->user_status=="registering" || $user_data->user_status=="declined"){
				$this->feedback->alert("failed", "Your account is inactive, please contact us for more info.");
				redirect('login');
			}
			else if($user_data->user_status == "active"){
				$this->session->set_userdata("mainsys-login", 1);
				$this->session->set_userdata("mainsys-user", $user_data);
				redirect('dashboard');
			}
		}
	}

	public function logout() {
  		$this->session->unset_userdata('mainsys-user');
		session_destroy();
		redirect('login','refresh');
	}
}
?>