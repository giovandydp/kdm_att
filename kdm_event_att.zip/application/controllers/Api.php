<?php
//GLOBAL SCOPE , DO NOT USE USER SPECIFIC SESSION
defined('BASEPATH') OR exit('No direct script access allowed');

class api extends CI_Controller {
	public function __construct(){
		parent::__construct();
	}

	public function get_users(){
        $user_id = $this->input->get('user_id');
        // $user_id = "testnotfound";
        // echo "masuk api";
        // echo "<pre>"; var_dump($user_id);echo "</pre>";exit;
        $ch = curl_init();
        $url = 'https://ejsoft.my.id/api/users?user_id='.$user_id;
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
        $result=curl_exec($ch);
        $result = json_decode($result);
        curl_close($ch);
        // echo "<pre>"; var_dump($result);echo "</pre>";exit;
        if(isset($result->name)){
            echo $this->builder->json_response(1, $result);
        }else{
            echo $this->builder->json_response(0, $result);
        }
        // return $result;
    }

    public function post_attendances(){
        $event_id = $this->input->post('event_id');
        $user_id = $this->input->post('user_id');
        // echo "<pre>"; var_dump($event_id);echo "</pre><br><br>";
        // echo "<pre>"; var_dump($user_id);echo "</pre>";exit;

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://ejsoft.my.id/api/attendances',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_HTTPHEADER => array('Content-Type: application/json'),
            CURLOPT_POSTFIELDS =>'{
                "event_id": "'.$event_id.'",
                "user_id": "'.$user_id.'"
            }'
        ));

        $result = curl_exec($curl);
        $result = json_decode($result);
        curl_close($curl);
        // echo "<pre>"; var_dump($result);echo "</pre>";exit;
        
        if(isset($result->name)){
            echo $this->builder->json_response(1, $result);
        }else{
            echo $this->builder->json_response(0, $result);
        }
    }
}