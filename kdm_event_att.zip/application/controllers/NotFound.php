<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Notfound extends CI_Controller {
	
	public $view_data;

	public function __construct() {
		parent::__construct();
		$this->view_data['title'] = '404 - Not Found';

		if (!$this->session->userdata('language')) {
			$this->session->set_userdata('language', 'indonesia');
			$this->session->set_userdata('country', 2);
		}
		if (!$this->session->userdata('is_login')) {
			$this->session->set_userdata("last_url", uri_string());
			redirect('login');
		}
	}

	public function index() {
		$this->template->template_frontend($this->view_data);

		// This line below is a must
		$this->view_data['content'] = $this->load->view("frontend/view_folder/404", $this->view_data, true);
		$this->load->view("frontend/master_layout", $this->view_data);
	}
}