<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class dashboard extends CI_Controller {
	protected $subject="Dashboard";
	protected $main_controller="dashboard";
	protected $view_data=[];

	public function __construct() {
		parent::__construct();
		$this->view_data['title'] = 'Dashboard';

		if ($this->session->userdata('mainsys-login')) {}
		else {
			redirect('login');
		}
		
		$this->load->model('data_grabber/dg_user');
	}

	public function index() {
		$this->template->template_mainsys($this->view_data);
		$this->view_data['content'] = $this->load->view("mainsys/content/dashboard/dashboard_view", $this->view_data, true);
		$this->load->view("mainsys/template/master_layout", $this->view_data);
	}
}