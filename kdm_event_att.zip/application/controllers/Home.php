<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class home extends CI_Controller {
	protected $subject="IJ Production System";
	protected $main_controller="home";
	protected $view_data=[];

	public function __construct() {
		parent::__construct();
		$this->view_data['title'] = $this->subject;
	}

	public function index() {
		redirect('login');
	}
}