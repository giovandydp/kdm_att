<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class greeting extends CI_Controller {
	protected $subject="Syalom!";
	protected $view_data=[];

	public function __construct() {
		parent::__construct();
		$this->view_data['title'] = 'Syalom!';
		
		$this->load->model('data_grabber/dg_event');
	}

	public function attendance($event_uid) {
		$this->template->template_mainsys($this->view_data);

		$event_data = $this->dg_event->where('event.event_uid',$event_uid)->single();

		$this->view_data['event_data'] = $event_data;
		$this->load->view("mainsys/content/greeting/greeting_view", $this->view_data);
	}

	public function attendance_beta() {
		$this->template->template_mainsys($this->view_data);

		$this->load->view("mainsys/content/greeting/betagreeting_view", $this->view_data);
	}

	public function register_beta() {
		$this->template->template_mainsys($this->view_data);
		
		$this->load->view("mainsys/content/greeting/betaregister_view", $this->view_data);
	}

	public function submit_betaregister(){
		$this->load->model('api/kdm_att');

		$val = $this->input->post('user');
		$val['birth_date'] = $val['birth_year']."-".str_pad($val['birth_month'],2,"0",STR_PAD_LEFT)."-".str_pad($val['birth_day'],2,"0",STR_PAD_LEFT);
		// echo "<pre>";var_dump($val);echo "</pre>";exit;

		$register = $this->kdm_att->register_user($val);
		// echo "<pre>";var_dump($register);echo "</pre>";exit;
		if($register){
			$this->feedback->alert("success", "New Member Registered");
			redirect('greeting/attendance_beta');
		}else{
			$this->feedback->alert("failed", "Failed to Register New Member");
			redirect('greeting/attendance_beta');
		}
	}
}