<?php
//GLOBAL SCOPE , DO NOT USE USER SPECIFIC SESSION
defined('BASEPATH') OR exit('No direct script access allowed');

class ajax extends CI_Controller {
	public function __construct(){
		parent::__construct();
	}

	public function confirm_attendance(){
		$this->load->model("data_grabber/dg_event");
		$this->load->model("data_grabber/dg_event_att");
		$this->load->model("data_grabber/dg_member");

		$event_uid = $this->input->get('euid');
		$member_uid = $this->input->get('muid');
		$check_member = $this->dg_member->select('member.member_uid, member.member_firstname, member.member_lastname')->where('member.member_uid',$member_uid)->single();

		$check_att_exist = $this->dg_event_att->where("event_att.event_uid",$event_uid)->where("event_att.member_uid",$member_uid)->single();
		if(empty($check_att_exist)){
			$att_data['event_uid'] = $event_uid;
			$att_data['member_uid'] = $member_uid;
			$att_data['event_att_dt'] = date('Y-m-d H:i:s');
			$this->dg_event_att->insert($att_data);
		}

		if(!empty($check_member)){
			echo $this->builder->json_response(1, $check_member);
		}else{
			echo $this->builder->json_response(0, $check_member);
		}
	}

	public function get_event_att(){
		
	}
}