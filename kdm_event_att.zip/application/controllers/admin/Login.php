<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class login extends CI_Controller {
	protected $subject="Login";
	protected $main_controller="login";
	protected $view_data=[];

	public function __construct() {
		parent::__construct();
		$this->view_data['subject'] = $this->subject;
		$this->load->model('authentication');
		$this->load->model('data_grabber/dg_admin');
		if (!$this->session->userdata('language')) {
			$this->session->set_userdata('language', 'english');
			$this->session->set_userdata('country', 1);
		}
		$this->view_data['main_controller']=$this->main_controller;
	}

	public function index() {
		$this->admin_login();
	}

	public function admin_login(){
		$this->template->template_salesoffice($this->view_data);

		$this->view_data['country'] = $this->query->select("*")->from("country")->allResult();

		$this->view_data['content'] = $this->load->view("salesoffice/content/login/login_form", $this->view_data, true);
		$this->load->view("salesoffice/template/master_layout_login", $this->view_data);
	}

	public function do_login() {
		$data = $this->input->post('login');
		
		// $abc = $this->authentication->encrypt($data['password']);
		// echo "<pre>";var_dump($abc);echo "</pre>";exit;

		$username = strtolower($data['username']);
		$password = $this->authentication->encrypt(strtolower($data['password']));

		$user_data = $this->dg_admin->select("admin.*, admin_role.*, admin_division.*")->where("admin.username",$username)->where("admin.password",$password)->where_in("admin.admin_division_id",[2,1])->single();
		if (empty($user_data)) {
			$this->feedback->alert("failed", "Wrong Username/Password");	

			redirect('salesoffice/login');
		} else {

			if($user_data->status == "banned"){
				$this->feedback->alert("failed", "Your account has been banned");
				redirect('salesoffice/login');
			}
			else if($user_data->status == "inactive"){
				$this->feedback->alert("failed", "Your account inactive");
				redirect('salesoffice/login');
			}
			else if($user_data->status == "active"){
				$current_time=date("Y-m-d H:i:s");
				$this->session->set_userdata("salesoffice-login", 1);
				$this->session->set_userdata("salesoffice-user", $user_data);
				$this->dg_system_log->insert(["log_type"=>"login","description"=>"[".$user_data->username."][".$user_data->division_name."] has logged in [".$current_time."]"]);
				$this->dg_admin->update(["last_login"=>$current_time],["admin_id"=>$user_data->admin_id]);
				redirect('salesoffice/dashboard');
			}
		}
	}

	public function logout() {
		$current_time=date("Y-m-d H:i:s");
		$user_logout = $this->session->userdata('salesoffice-user')->username;
		$user_division = $this->session->userdata('salesoffice-user')->division_name;
		$this->dg_system_log->insert(["log_type"=>"login","description"=>"[".$user_logout."][".$user_division."] has logged out [".$current_time."]"]);
		session_destroy();
		redirect('salesoffice/login','refresh');
	}
}
?>