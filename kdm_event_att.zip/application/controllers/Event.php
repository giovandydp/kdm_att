<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class event extends CI_Controller {
	protected $subject="Events";
	protected $view_data=[];

	public function __construct() {
		parent::__construct();
		$this->view_data['title'] = 'Events';

		if ($this->session->userdata('mainsys-login')) {}
		else {
			redirect('login');
		}
	}

	public function index() {
		$this->manage_event();
	}

	public function manage_event() {
		$this->template->template_mainsys($this->view_data);
		$this->load->model('data_grabber/dg_event');

		$params=$this->input->get();
	    if(!empty($params)){
		    $data_builder = $this->dg_event->select("event.*");
		    if(isset($params['uid']) && !empty($params['uid'])){
		      $data_builder->like('event.event_uid',$params['uid']);
		    }
		    if(isset($params['range']['from_date']) && !empty($params['range']['from_date'])){
		      $data_builder->where('date(event.schedule_dt) >=',$params['range']['from_date']);
		    }
		    if(isset($params['range']['to_date']) && !empty($params['range']['to_date'])){
		      $data_builder->where('date(event.schedule_dt) <=',$params['range']['to_date']);
		    }
		    $data_builder->order_by('event.created_dt DESC');
			$this->view_data['data_list']=$data_builder->glist();
		}
		else{
			$this->view_data['data_list']=$this->dg_event->select("event.*")->order_by('event.created_dt DESC')->glist();
		}
        
		$this->view_data['params']=$params;
		$this->view_data['content'] = $this->load->view("mainsys/content/event/manage_event", $this->view_data, true);
		$this->load->view("mainsys/template/master_layout", $this->view_data);
	}

	public function add_event(){
		$this->template->template_mainsys($this->view_data);
		$this->load->model('data_grabber/dg_location');

		$this->view_data['location_list'] = $this->dg_location->glist();
		$this->view_data['content'] = $this->load->view("mainsys/content/event/add_event", $this->view_data, true);
		$this->load->view("mainsys/template/master_layout", $this->view_data);
	}

	public function submit_event(){
		$this->load->model('data_grabber/dg_event');

		$new_data = $this->input->post('event');

		$current_dt = date('Y-m-d H:i:s');
		$new_data['event_uid'] = $this->keygen->generate_event_uid($new_data['event_type'],$current_dt);
		$new_data['event_status'] = "checking";
		$new_data['created_dt'] = $current_dt;
		$new_data['created_by'] = $this->session->userdata('mainsys-user')->user_id;
		// echo "<pre>";var_dump($new_data);echo "</pre?";exit;

		if($this->dg_event->insert($new_data)){
			$this->feedback->alert("success", "New event created.");
			redirect('event/manage_event?uid='.$new_data['event_uid']);
		}else{
			$this->feedback->alert("failed", "Failed to create new event.");
			redirect('event/manage_event');
		}
	}
}