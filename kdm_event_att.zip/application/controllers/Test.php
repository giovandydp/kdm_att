<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends CI_Controller {
	
	public $view_data;

	public function __construct() {
		parent::__construct();
	}

	public function index() {
		echo date("Y-m-d H:i:s");
	}

	public function test_event(){
		$current_dt = date('Y-m-d H:i:s');
		$show_code = $this->keygen->generate_event_uid("onsite",$current_dt);
		echo $show_code;
	}

	public function test_member(){
		$current_dt = date('Y-m-d H:i:s');
		$show_code = $this->keygen->generate_member_uid("KDM",$current_dt);
		echo $show_code;
	}

	public function check_pass23($set){
		$this->load->model('authentication');
		$abc = $this->authentication->encrypt($set);
		echo "<pre>";var_dump($abc);echo "</pre>";exit;
	}

}