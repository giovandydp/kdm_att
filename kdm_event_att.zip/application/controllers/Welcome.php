<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index() {
		$this->load->view('welcome_message');
	}

	public function coba_email() {
		$this->load->library('email');

		$subject = 'This is a test';
		$message = '<p class="red">This message has been sent for testing purposes.</p>';

		// Get full html:
		$body = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
		<html xmlns="http://www.w3.org/1999/xhtml">
		<head>
		    <meta http-equiv="Content-Type" content="text/html; charset=' . strtolower(config_item('charset')) . '" />
		    <title>' . html_escape($subject) . '</title>
		    <style type="text/css">
		        body {
		            font-family: Arial, Verdana, Helvetica, sans-serif;
		            font-size: 30px;
		            color: red;
		        }
		        .red {
		        	color: red;
		        }
		    </style>
		</head>
		<body>
		' . $message . '
		</body>
		</html>';
		// Also, for getting full html you may use the following internal method:
		//$body = $this->email->full_html($subject, $message);

		$result = $this->email
		    ->from('albertsusanto94@gmail.com', 'Dagang')
		    ->to('albertssnto@gmail.com')
		    ->subject($subject)
		    ->message($body)
		    ->send();

		var_dump($result);
		echo '<br />';
		echo $this->email->print_debugger();

		exit;
	}

	public function coba_select() {
		$data = $this->query->select("*")
		->from("gudang")
		->where("id", 5)
		->valueResult("name");

		// echo $this->db->last_query();
		echo "<pre>";print_r($data);
	}

	public function coba_insert() {
		$data = array('name' => 'Hihi');
		
		$insert = $this->query->insert("gudang", $data);	

		// echo $this->db->last_query();
		echo "<pre>";print_r($insert);
	}

	public function coba_update() {
		$data = array('name' => 'koplak');
		$where = array('id' => 47);

		$update = $this->query->update("gudang", $data, $where);

		// echo $this->db->last_query();
		echo "<pre>";print_r($update);
	}

	public function coba_delete() {
		$where = array('id' => 47);

		$delete = $this->query->delete("gudang", $where);

		// echo $this->db->last_query();
		echo "<pre>";print_r($delete);
	}
}
